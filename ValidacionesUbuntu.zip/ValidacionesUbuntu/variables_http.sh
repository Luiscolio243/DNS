#!/bin/bash
#VARIABLES UTILIZADAS: 
url_apache="https://httpd.apache.org/download.cgi"
url_nginx="https://nginx.org/en/download.html"
url_litespeed="https://openlitespeed.org/downloads/"
url_apache_descargas="https://downloads.apache.org/httpd/"
url_litespeed_descargas="https://openlitespeed.org/packages/"
url_nginx_descargas="https://nginx.org/download/"