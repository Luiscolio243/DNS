# Función para validar una dirección IP
function ValidarIP {
    param (
        [string]$ip
    )
    # Validar direcciones IPv4
    $patron = "^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"
    return $ip -match $patron
}